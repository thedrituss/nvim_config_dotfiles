return {
  "nvim-treesitter/nvim-treesitter",
  opts = function(_, opts)
    if type(opts.ensure_installed) == "table" then vim.list_extend(opts.ensure_installed, { "python" }) end
  end,
  config = function()
    -- Configuración de indentación básica para Python
    vim.cmd [[autocmd FileType python setlocal tabstop=4 shiftwidth=4 expandtab]]

    -- Formateo al guardar usando LSP (requiere que el LSP de Python esté funcionando)
    vim.api.nvim_create_autocmd("BufWritePre", {
      pattern = "*.py",
      callback = function() vim.lsp.buf.format { async = false } end,
    })
  end,
}
