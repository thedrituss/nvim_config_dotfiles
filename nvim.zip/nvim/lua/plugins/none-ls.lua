return {
  "nvimtools/none-ls.nvim",
  dependencies = { "nvim-lua/plenary.nvim" },
  config = function()
    local null_ls = require "null-ls" -- ← Correct module name
    local ruff_formatting = {
      method = null_ls.methods.FORMATTING,
      filetypes = { "python" },
      generator = null_ls.formatter {
        command = "ruff",
        args = { "format", "--stdin-filename", "$FILENAME", "-" },
        to_stdin = true,
      },
    }
    null_ls.setup {
      sources = {
        ruff_formatting,
        null_ls.builtins.formatting.ruff,
        null_ls.builtins.diagnostics.ruff,
      },
    }
  end,
}
