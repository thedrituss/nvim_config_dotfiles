return {
  "mfussenegger/nvim-dap",
  dependencies = {
    "rcarriga/nvim-dap-ui",
    "nvim-telescope/telescope-dap.nvim",
    "theHamsta/nvim-dap-virtual-text",
    "williamboman/mason.nvim",
    "jay-babu/mason-nvim-dap.nvim",
  },
  config = function()
    local dap = require("dap")
    local dapui = require("dapui")

    require("mason-nvim-dap").setup({
      -- automatically install debuggers for these languages
      automatic_installation = true,
      ensure_installed = {
        "python",
      },
    })

    dapui.setup({
      layouts = {
        {
          elements = {
            -- Elements for the first layout
            { id = "scopes", size = 0.3 },
            { id = "breakpoints", size = 0.2 },
            { id = "stacks", size = 0.2 },
            { id = "watches", size = 0.3 },
          },
          size = 40, -- size of the first layout
          position = "right",
        },
        {
          elements = {
            { id = "repl", size = 0.5 },
            { id = "console", size = 0.5 },
          },
          size = 0.25, -- size of the second layout
          position = "bottom",
        },
      },
    })

    dap.listeners.after.event("initialized", function()
      dapui.open()
    end)
    dap.listeners.before.event("terminated", function()
      dapui.close()
    end)
    dap.listeners.before.event("disconnect", function()
      dapui.close()
    end)

    dap.configurations.python = {
      {
        type = "python",
        request = "launch",
        name = "Launch file",
        program = "${file}",
        pythonPath = function()
          return ".venv/bin/python"
        end,
      },
    }

    -- Keymaps for debugging
    vim.keymap.set("n", "<F5>", dap.continue, { desc = "DAP: Continue" })
    vim.keymap.set("n", "<F10>", dap.step_over, { desc = "DAP: Step Over" })
    vim.keymap.set("n", "<F11>", dap.step_into, { desc = "DAP: Step Into" })
    vim.keymap.set("n", "<F12>", dap.step_out, { desc = "DAP: Step Out" })
    vim.keymap.set("n", "<leader>b", dap.toggle_breakpoint, { desc = "DAP: Toggle Breakpoint" })
    vim.keymap.set("n", "<leader>B", function()
      dap.set_breakpoint(vim.fn.input("Breakpoint condition: "))
    end, { desc = "DAP: Set Breakpoint with condition" })
    vim.keymap.set("n", "<leader>lp", function()
      dap.set_breakpoint(nil, nil, vim.fn.input("Log point message: "))
    end, { desc = "DAP: Set Log Point" })
    vim.keymap.set("n", "<leader>dr", dap.repl.toggle, { desc = "DAP: Toggle REPL" })
    vim.keymap.set("n", "<leader>dl", function()
      dap.run_last()
    end, { desc = "DAP: Run Last" })
    vim.keymap.set({ "n", "v" }, "<leader>dh", function()
      require("dap.ui.widgets").hover()
    end, { desc = "DAP: Hover" })
    vim.keymap.set({ "n", "v" }, "<leader>dp", function()
      require("dap.ui.widgets").preview()
    end, { desc = "DAP: Preview" })
    vim.keymap.set("n", "<leader>do", dapui.eval, { desc = "DAP: Evaluate" })
  end,
}


